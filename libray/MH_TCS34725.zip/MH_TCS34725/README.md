# ColorSensor
DFRobot's ColorSensor

 * file colorview.ino interrupt.ino tcs34725autorange.ino tcs34725.ino
 * brief DFRobot's color sensor
 * [Get the module here](此处为购买链接，上架后修改)
 * This example get the four lightest positions of the IR sources.
 * [Connection and Diagram](http://wiki.dfrobot.com.cn/index.php?title=(SKU:SEN0212)Color_Sensor-TCS34725_%E9%A2%9C%E8%89%B2%E4%BC%A0%E6%84%9F%E5%99%A8)
 *
 * Copyright	[DFRobot](http://www.dfrobot.com), 2016
 * Copyright	GNU Lesser General Public License
 *
 * author [carl](carl.xu@dfrobot.com)
 * version  V1.0
 * date  2016-07-07